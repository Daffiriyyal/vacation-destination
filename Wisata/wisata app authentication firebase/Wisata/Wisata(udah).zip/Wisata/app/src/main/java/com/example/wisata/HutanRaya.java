package com.example.wisata;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HutanRaya extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hutan_raya);
    }
}